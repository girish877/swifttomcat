package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class index_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final javax.servlet.jsp.JspFactory _jspxFactory =
          javax.servlet.jsp.JspFactory.getDefaultFactory();

  private static java.util.List<java.lang.String> _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.tomcat.InstanceManager _jsp_instancemanager;

  public java.util.List<java.lang.String> getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_instancemanager = org.apache.jasper.runtime.InstanceManagerFactory.getInstanceManager(getServletConfig());
  }

  public void _jspDestroy() {
  }

  public void _jspService(final javax.servlet.http.HttpServletRequest request, final javax.servlet.http.HttpServletResponse response)
        throws java.io.IOException, javax.servlet.ServletException {

    final javax.servlet.jsp.PageContext pageContext;
    javax.servlet.http.HttpSession session = null;
    final javax.servlet.ServletContext application;
    final javax.servlet.ServletConfig config;
    javax.servlet.jsp.JspWriter out = null;
    final java.lang.Object page = this;
    javax.servlet.jsp.JspWriter _jspx_out = null;
    javax.servlet.jsp.PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("<!DOCTYPE html>\r\n");

java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy");
request.setAttribute("year", sdf.format(new java.util.Date()));
request.setAttribute("tomcat7Url", "http://tomcat.apache.org/");
request.setAttribute("tomcat7DocUrl", "/docs/");

      out.write("\r\n");
      out.write("<html lang=\"en\">\r\n");
      out.write("    <head>\r\n");
      out.write("        <title>");
      out.print(request.getServletContext().getServerInfo() );
      out.write("</title>\r\n");
      out.write("        <link href=\"favicon.ico\" rel=\"icon\" type=\"image/x-icon\" />\r\n");
      out.write("        <link href=\"favicon.ico\" rel=\"shortcut icon\" type=\"image/x-icon\" />\r\n");
      out.write("        <link href=\"tomcat.css\" rel=\"stylesheet\" type=\"text/css\" />\r\n");
      out.write("    </head>\r\n");
      out.write("\r\n");
      out.write("    <body>\r\n");
      out.write("        <div id=\"wrapper\">\r\n");
      out.write("            <div id=\"navigation\" class=\"curved container\">\r\n");
      out.write("                <span id=\"nav-home\"><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7Url}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("\">Home</a></span>\r\n");
      out.write("                <span id=\"nav-hosts\"><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7DocUrl}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("\">Documentation</a></span>\r\n");
      out.write("                <span id=\"nav-hosts\"><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7DocUrl}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("config/\">Configuration</a></span>\r\n");
      out.write("                <span id=\"nav-wiki\"><a href=\"http://wiki.apache.org/tomcat/FrontPage\">Wiki</a></span>\r\n");
      out.write("                <span id=\"nav-lists\"><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7Url}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("lists.html\">Mailing Lists</a></span>\r\n");
      out.write("                <span id=\"nav-help\"><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7Url}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("findhelp.html\">Find Help</a></span>\r\n");
      out.write("                <br class=\"separator\" />\r\n");
      out.write("            </div>\r\n");
      out.write("            <div id=\"asf-box\">\r\n");
      out.write("                <div id=\"version\">\r\n");
      out.write("                    <h1>");
      out.print(request.getServletContext().getServerInfo() );
      out.write("</h1>\r\n");
      out.write("                </div>\r\n");
      out.write("                <div id=\"upper-asf\">\r\n");
      out.write("                    <a href=\"http://www.apache.org/\"><img src=\"asf-logo.png\" /></a>\r\n");
      out.write("                </div>\r\n");
      out.write("                <br class=\"separator\" />\r\n");
      out.write("            </div>\r\n");
      out.write("            <div id=\"upper\" class=\"curved container\">\r\n");
      out.write("                <div id=\"congrats\" class=\"curved container\">\r\n");
      out.write("                    <h2>If you're seeing this, you've successfully installed Tomcat. Congratulations!</h2>\r\n");
      out.write("                </div>\r\n");
      out.write("                <div id=\"notice\">\r\n");
      out.write("                    <img src=\"tomcat.png\" alt=\"[tomcat logo]\" />\r\n");
      out.write("                    <div id=\"tasks\">\r\n");
      out.write("                        <h3>Recommended Reading:</h3>\r\n");
      out.write("                        <h4><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7DocUrl}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("security-howto.html\">Security Considerations HOW-TO</a></h4>\r\n");
      out.write("                        <h4><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7DocUrl}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("manager-howto.html\">Manager Application HOW-TO</a></h4>\r\n");
      out.write("                        <h4><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7DocUrl}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("cluster-howto.html\">Clustering/Session Replication HOW-TO</a></h4>\r\n");
      out.write("                    </div>\r\n");
      out.write("                </div>\r\n");
      out.write("                <div id=\"actions\">\r\n");
      out.write("                    <div class=\"button\">\r\n");
      out.write("                        <a class=\"container shadow\" href=\"/manager/status\"><span>Server Status</span></a>\r\n");
      out.write("                    </div>\r\n");
      out.write("                    <div class=\"button\">\r\n");
      out.write("                        <a class=\"container shadow\" href=\"/manager/html\"><span>Manager App</span></a>\r\n");
      out.write("                    </div>\r\n");
      out.write("                    <div class=\"button\">\r\n");
      out.write("                        <a class=\"container shadow\" href=\"/host-manager/html\"><span>Host Manager</span></a>\r\n");
      out.write("                    </div>\r\n");
      out.write("                </div>\r\n");
      out.write("                <!--\r\n");
      out.write("                <br class=\"separator\" />\r\n");
      out.write("                -->\r\n");
      out.write("                <br class=\"separator\" />\r\n");
      out.write("            </div>\r\n");
      out.write("            <div id=\"middle\" class=\"curved container\">\r\n");
      out.write("                <h3>Developer Quick Start</h3>\r\n");
      out.write("                <div class=\"col25\">\r\n");
      out.write("                    <div class=\"container\">\r\n");
      out.write("                        <p><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7DocUrl}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("setup.html\">Tomcat Setup</a></p>\r\n");
      out.write("                        <p><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7DocUrl}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("appdev/\">First Web Application</a></p>\r\n");
      out.write("                    </div>\r\n");
      out.write("                </div>\r\n");
      out.write("                <div class=\"col25\">\r\n");
      out.write("                    <div class=\"container\">\r\n");
      out.write("                        <p><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7DocUrl}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("realm-howto.html\">Realms &amp; AAA</a></p>\r\n");
      out.write("                        <p><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7DocUrl}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("jndi-datasource-examples-howto.html\">JDBC DataSources</a></p>\r\n");
      out.write("                    </div>\r\n");
      out.write("                </div>\r\n");
      out.write("                <div class=\"col25\">\r\n");
      out.write("                    <div class=\"container\">\r\n");
      out.write("                        <p><a href=\"/examples/servlets/\">Servlet Examples</a></p>\r\n");
      out.write("                        <p><a href=\"/examples/jsp/\">JSP Examples</a></p>\r\n");
      out.write("                    </div>\r\n");
      out.write("                </div>\r\n");
      out.write("                <div class=\"col25\">\r\n");
      out.write("                    <div class=\"container\">\r\n");
      out.write("                        <p><a href=\"http://wiki.apache.org/tomcat/Specifications\">Servlet Specifications</a></p>\r\n");
      out.write("                        <p><a href=\"http://wiki.apache.org/tomcat/TomcatVersions\">Tomcat Versions</a></p>\r\n");
      out.write("                    </div>\r\n");
      out.write("                </div>\r\n");
      out.write("                <br class=\"separator\" />\r\n");
      out.write("            </div>\r\n");
      out.write("            <div id=\"lower\">\r\n");
      out.write("                <div id=\"low-manage\" class=\"\">\r\n");
      out.write("                    <div class=\"curved container\">\r\n");
      out.write("                        <h3>Managing Tomcat</h3>\r\n");
      out.write("                        <p>For security, access to the <a href=\"/manager/html\">manager webapp</a> is restricted.\r\n");
      out.write("                        Users are defined in:</p>\r\n");
      out.write("                        <pre>$CATALINA_HOME/conf/tomcat-users.xml</pre>\r\n");
      out.write("                        <p>In Tomcat 7.0 access to the manager application is split between different users.</p>\r\n");
      out.write("                        <p><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7DocUrl}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("manager-howto.html\">Read more...</a></p>\r\n");
      out.write("                        <br />\r\n");
      out.write("                        <h4><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7DocUrl}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("RELEASE-NOTES.txt\">Release Notes</a></h4>\r\n");
      out.write("                        <h4><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7DocUrl}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("changelog.html\">Changelog</a></h4>\r\n");
      out.write("                        <h4><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7Url}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("migration.html\">Migration Guide</a></h4>\r\n");
      out.write("                        <h4><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7Url}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("security.html\">Security Updates</a></h4>\r\n");
      out.write("\r\n");
      out.write("                    </div>\r\n");
      out.write("                </div>\r\n");
      out.write("                <div id=\"low-docs\" class=\"\">\r\n");
      out.write("                    <div class=\"curved container\">\r\n");
      out.write("                        <h3>Documentation</h3>\r\n");
      out.write("                        <h4><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7DocUrl}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("\">Tomcat 7.0 Documentation</a></h4>\r\n");
      out.write("                        <h4><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7DocUrl}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("config/\">Tomcat 7.0 Configuration</a></h4>\r\n");
      out.write("                        <h4><a href=\"http://wiki.apache.org/tomcat/FrontPage\">Tomcat Wiki</a></h4>\r\n");
      out.write("                        <p>Find additional important configuration information in:</p>\r\n");
      out.write("                        <pre>$CATALINA_HOME/RUNNING.txt</pre>\r\n");
      out.write("                        <p>Developers may be interested in:</p>\r\n");
      out.write("                        <ul>\r\n");
      out.write("                            <li><a href=\"https://issues.apache.org/bugzilla/buglist.cgi?bug_status=UNCONFIRMED&amp;bug_status=NEW&amp;bug_status=ASSIGNED&amp;bug_status=REOPENED&amp;bug_status=RESOLVED&amp;resolution=LATER&amp;resolution=REMIND&amp;resolution=---&amp;bugidtype=include&amp;product=Tomcat+7&amp;cmdtype=doit&amp;order=Importance\">Tomcat 7.0 Bug Database</a></li>\r\n");
      out.write("                            <li><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7DocUrl}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("api/index.html\">Tomcat 7.0 JavaDocs</a></li>\r\n");
      out.write("                            <li><a href=\"http://svn.apache.org/repos/asf/tomcat/tc7.0.x/\">Tomcat 7.0 SVN Repository</a></li>\r\n");
      out.write("                            <li><a href=\"/examples/\">Tomcat 7.0 Examples</a></li>\r\n");
      out.write("                        </ul>\r\n");
      out.write("                    </div>\r\n");
      out.write("                </div>\r\n");
      out.write("                <div id=\"low-help\" class=\"\">\r\n");
      out.write("                    <div class=\"curved container\">\r\n");
      out.write("                        <h3>Getting Help</h3>\r\n");
      out.write("                        <h4><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7Url}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("faq/\">FAQ</a></h4>\r\n");
      out.write("                        <h4><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7Url}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("lists.html\">Mailing Lists</a></h4>\r\n");
      out.write("                        <p>The following mailing lists are available:</p>\r\n");
      out.write("                        <ul>\r\n");
      out.write("                            <li id=\"list-announce\"><strong><a href=\"mailto:announce-subscribe@tomcat.apache.org\">announce@tomcat.apache.org</a><br />\r\n");
      out.write("                                Important announcements, releases, security vulnerability notifications. (Low volume).</strong>\r\n");
      out.write("                            </li>\r\n");
      out.write("                            <li><a href=\"mailto:users-subscribe@tomcat.apache.org\">users@tomcat.apache.org</a><br />\r\n");
      out.write("                                User support and discussion\r\n");
      out.write("                            </li>\r\n");
      out.write("                            <li><a href=\"mailto:taglibs-user-subscribe@tomcat.apache.org\">taglibs-user@tomcat.apache.org</a><br />\r\n");
      out.write("                                User support and discussion for <a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7Url}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("taglibs/\">Apache Taglibs</a>\r\n");
      out.write("                            </li>\r\n");
      out.write("                            <li><a href=\"mailto:dev-subscribe@tomcat.apache.org\">dev@tomcat.apache.org</a><br />\r\n");
      out.write("                                Development mailing list, including commit messages\r\n");
      out.write("                            </li>\r\n");
      out.write("                        </ul>\r\n");
      out.write("                    </div>\r\n");
      out.write("                </div>\r\n");
      out.write("                <br class=\"separator\" />\r\n");
      out.write("            </div>\r\n");
      out.write("            <div id=\"footer\" class=\"curved container\">\r\n");
      out.write("                <div class=\"col20\">\r\n");
      out.write("                    <div class=\"container\">\r\n");
      out.write("                        <h4>Other Downloads</h4>\r\n");
      out.write("                        <ul>\r\n");
      out.write("                            <li><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7Url}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("download-connectors.cgi\">Tomcat Connectors</a></li>\r\n");
      out.write("                            <li><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7Url}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("download-native.cgi\">Tomcat Native</a></li>\r\n");
      out.write("                            <li><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7Url}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("taglibs/\">Taglibs</a></li>\r\n");
      out.write("                            <li><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7DocUrl}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("deployer-howto.html\">Deployer</a></li>\r\n");
      out.write("                        </ul>\r\n");
      out.write("                    </div>\r\n");
      out.write("                </div>\r\n");
      out.write("                <div class=\"col20\">\r\n");
      out.write("                    <div class=\"container\">\r\n");
      out.write("                        <h4>Other Documentation</h4>\r\n");
      out.write("                        <ul>\r\n");
      out.write("                            <li><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7Url}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("connectors-doc/\">Tomcat Connectors</a></li>\r\n");
      out.write("                            <li><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7Url}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("connectors-doc/\">mod_jk Documentation</a></li>\r\n");
      out.write("                            <li><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7Url}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("native-doc/\">Tomcat Native</a></li>\r\n");
      out.write("                            <li><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7DocUrl}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("deployer-howto.html\">Deployer</a></li>\r\n");
      out.write("                        </ul>\r\n");
      out.write("                    </div>\r\n");
      out.write("                </div>\r\n");
      out.write("                <div class=\"col20\">\r\n");
      out.write("                    <div class=\"container\">\r\n");
      out.write("                        <h4>Get Involved</h4>\r\n");
      out.write("                        <ul>\r\n");
      out.write("                            <li><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7Url}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("getinvolved.html\">Overview</a></li>\r\n");
      out.write("                            <li><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7Url}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("svn.html\">SVN Repositories</a></li>\r\n");
      out.write("                            <li><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7Url}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("lists.html\">Mailing Lists</a></li>\r\n");
      out.write("                            <li><a href=\"http://wiki.apache.org/tomcat/FrontPage\">Wiki</a></li>\r\n");
      out.write("                        </ul>\r\n");
      out.write("                    </div>\r\n");
      out.write("                </div>\r\n");
      out.write("                <div class=\"col20\">\r\n");
      out.write("                    <div class=\"container\">\r\n");
      out.write("                        <h4>Miscellaneous</h4>\r\n");
      out.write("                        <ul>\r\n");
      out.write("                            <li><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7Url}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("contact.html\">Contact</a></li>\r\n");
      out.write("                            <li><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7Url}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("legal.html\">Legal</a></li>\r\n");
      out.write("                            <li><a href=\"http://www.apache.org/foundation/sponsorship.html\">Sponsorship</a></li>\r\n");
      out.write("                            <li><a href=\"http://www.apache.org/foundation/thanks.html\">Thanks</a></li>\r\n");
      out.write("                        </ul>\r\n");
      out.write("                    </div>\r\n");
      out.write("                </div>\r\n");
      out.write("                <div class=\"col20\">\r\n");
      out.write("                    <div class=\"container\">\r\n");
      out.write("                        <h4>Apache Software Foundation</h4>\r\n");
      out.write("                        <ul>\r\n");
      out.write("                            <li><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7Url}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("whoweare.html\">Who We Are</a></li>\r\n");
      out.write("                            <li><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7Url}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("heritage.html\">Heritage</a></li>\r\n");
      out.write("                            <li><a href=\"http://www.apache.org\">Apache Home</a></li>\r\n");
      out.write("                            <li><a href=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${tomcat7Url}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write("resources.html\">Resources</a></li>\r\n");
      out.write("                        </ul>\r\n");
      out.write("                    </div>\r\n");
      out.write("                </div>\r\n");
      out.write("                <br class=\"separator\" />\r\n");
      out.write("            </div>\r\n");
      out.write("            <p class=\"copyright\">Copyright &copy;1999-");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${year}", java.lang.String.class, (javax.servlet.jsp.PageContext)_jspx_page_context, null, false));
      out.write(" Apache Software Foundation.  All Rights Reserved</p>\r\n");
      out.write("        </div>\r\n");
      out.write("    </body>\r\n");
      out.write("\r\n");
      out.write("</html>\r\n");
    } catch (java.lang.Throwable t) {
      if (!(t instanceof javax.servlet.jsp.SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
